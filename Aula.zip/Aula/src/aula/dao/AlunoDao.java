/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula.dao;

import aula.model.Aluno;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;


public class AlunoDao {
    private Connection conn;
    
    public AlunoDao(Connection conn)
    {
        this.conn = conn;
    }
    
    public ResultSet consultar(Aluno aluno) throws SQLException {
        String sql = "select * from alunos where usuario = ? and senha = ?";
        
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(0, aluno.getUsuario());
        statement.setString(1, aluno.getSenha());
        statement.execute();
        
        ResultSet result = statement.getResultSet();
        return result;
    }
    
    public void inserir(Aluno aluno) throws SQLException {
        String sql = "insert into alunos(nome, usuario, senha) values ('"
                + aluno.getNome() + "', '"
                + aluno.getUsuario() + "', '"
                + aluno.getSenha()
                + "')";
        
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.execute();
        conn.close();
    }
    
    public void atualizar(Aluno aluno) throws SQLException {
        String sql = "update alunos set senha = ? where usuario = ?";
        
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(0, aluno.getUsuario());
        statement.setString(1, aluno.getSenha());
        statement.execute();
        conn.close();
    }
    
    public void remover(Aluno aluno) throws SQLException {
        String sql = "delete from alunos where usuario = ?";
        
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(0, aluno.getUsuario());
        statement.execute();
        conn.close();
    }
}
